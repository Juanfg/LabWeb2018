module.exports = {
  username: "juanf",
  password: "a",
  database: "sepomex",
  psql: {
    port: 5432,
    host: "127.0.0.1",
  },
  url: "postgresql://juanf:a@localhost:5432/sepomex"
};